import cv2
import numpy as np

# Open the webcam
camera = cv2.VideoCapture(0)

while True:

    # Capture a frame from the webcam
    success, frame = camera.read()

    # Check if the webcam is working
    if not success:
        print("Could not access the webcam.")
        break

    # Convert the frame from BGR to HSV
    hsv = cv2.cvtColor(frame, cv2.COLOR_BGR2HSV)

    # Lower and upper HSV values for RED
    lower_red1 = np.array([0, 120, 70])
    upper_red1 = np.array([10, 255, 255])

    lower_red2 = np.array([170, 120, 70])
    upper_red2 = np.array([180, 255, 255])

    # Create masks for the red color
    mask1 = cv2.inRange(hsv, lower_red1, upper_red1)
    mask2 = cv2.inRange(hsv, lower_red2, upper_red2)

    # Combine both red masks
    mask = mask1 + mask2

    # Find contours
    contours, _ = cv2.findContours(
        mask,
        cv2.RETR_EXTERNAL,
        cv2.CHAIN_APPROX_SIMPLE
    )

    # Check every detected contour
    for contour in contours:

        # Calculate the area
        area = cv2.contourArea(contour)

        # Ignore very small objects
        if area > 500:

            # Get the bounding rectangle
            x, y, width, height = cv2.boundingRect(contour)

            # Draw a rectangle around the detected red object
            cv2.rectangle(
                frame,
                (x, y),
                (x + width, y + height),
                (0, 255, 0),
                2
            )

            # Display text
            cv2.putText(
                frame,
                "RED DETECTED",
                (x, y - 10),
                cv2.FONT_HERSHEY_SIMPLEX,
                0.8,
                (0, 255, 0),
                2
            )

    # Display the webcam
    cv2.imshow("Color Detection", frame)

    # Display the color mask
    cv2.imshow("Red Color Mask", mask)

    # Press Q to quit
    if cv2.waitKey(1) & 0xFF == ord("q"):
        break

# Release the webcam
camera.release()

# Close all OpenCV windows
cv2.destroyAllWindows()
